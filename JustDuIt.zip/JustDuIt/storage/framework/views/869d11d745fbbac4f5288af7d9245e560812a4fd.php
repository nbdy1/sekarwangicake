<nav id="navbar" style="position: fixed;background: white">
  <input type="checkbox" id="check">

 
  <label for="check" id="lines">&#9776;</label>
  <a href="/home">
  <img src="<?php echo e(asset('assets/nike.png')); ?>" alt="" id="logoimg">
    <label id="logo" style="cursor: pointer;">Just Du It !</label>
    </a>

    <?php if((Route::currentRouteAction() != 'App\Http\Controllers\UserController@showLoginPage' && Route::currentRouteAction() != 'App\Http\Controllers\UserController@showRegisterPage')): ?>
  <form class="searchbar" action="filterproduct" style="display:inline;" method="GET">
  <input type="text" placeholder="Search.." name="keyword" class="searchfield">
  <button class="searchsubmit"type="submit"><span style="color: #174972">Search</span> </button>
</form>
<?php endif; ?>
   

    <ul>
      <?php if(!Auth::User()): ?>
      <li><a href="/login">Login</a></li>
      <li><a href="/register">Register</a></li>

      <?php else: ?>
      <li>
        <div class="dropdown">
          <button onclick="myFunction()" class="dropbtn"><?php echo e(Auth::user()->username); ?>    &#9660;</button>
          <div id="myDropdown" class="dropdown-content">
            <a href="/logout">Logout</a>
          </div>
        </div>
      </li>

      <?php endif; ?>

    </ul>
</nav>

<script>
  function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/layout/navbar.blade.php ENDPATH**/ ?>