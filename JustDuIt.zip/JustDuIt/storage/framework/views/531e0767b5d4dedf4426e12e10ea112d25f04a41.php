
<?php $__env->startSection('content'); ?>


<div class="editproductboxcart" style="">
  

    <div class="editcartimage">
        <img src="<?php echo e(asset('assets/' . $cart->product->image)); ?>" alt="" style="width: 15vw;">

    </div>

    <div class="editcartinformation">
        <h2 style="padding: 3vh;padding-bottom: 0; margin-top: 0px; font-weight: 100; font-size: 1.5em"><?php echo e($cart->product->name); ?></h2>
        <h4 style="padding-left: 3vh">Rp<?php echo e(number_format($cart->product->price)); ?></h4>
        <p style="padding-left: 3vh; max-width: 27vw;"><?php echo e($cart->product->description); ?></p>
        <form action="/editcart" method="POST" style="float:left">
        <?php echo csrf_field(); ?>
        <!-- Input ini buat passing ID nya biar bisa diterima -->
        <input type="hidden" name="productid" value="<?php echo e($cart->product->id); ?>">
                       
            <label for="quantity" style="padding-left: 1.5vw;">Quantity  </label>
                <input type="number" class="" value="<?php echo e($cart->quantity); ?>" name="quantity" style="width: 7vw; margin-left: 1vw; font-size: 1em;">

                    
                <button type="submit" class="editcartbutton" style="">Update Cart</a>   
               
    </form>
    <a href="/deletecart/<?php echo e($cart->product->id); ?>"><button class="editcartbutton" style="background: red;">Delete</button></a>
                   
    
    
    
    </div>

    <?php if($errors->any()): ?>
                    <div style="width:100%; display:flex;align-items: center; padding-left: 3vh " role="alert">
                        <h3 style="color: red"><?php echo e($errors->first()); ?></h3>
                    </div>
                <?php endif; ?>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/editcart.blade.php ENDPATH**/ ?>