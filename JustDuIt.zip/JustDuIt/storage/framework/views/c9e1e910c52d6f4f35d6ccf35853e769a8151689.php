
<?php $__env->startSection('content'); ?>


<div class="editproductboxcart">
    <div class="editproductboxheader">
        <h3>Edit Shoe</h3>
    </div>

    <div class="editproductimage">
        <img src="<?php echo e(asset('assets/' . $product->image)); ?>" alt="" style="width: 15vw;">

    </div>

    <div class="editproductinformation">
        <h2 style="padding: 3vh;padding-bottom: 0; margin-top: 0px; font-weight: 100; font-size: 1.5em"><?php echo e($product->name); ?></h2>
        <h4 style="padding-left: 3vh">Rp<?php echo e(number_format($product->price)); ?></h4>
        <p style="padding-left: 3vh; max-width: 27vw;"><?php echo e($product->description); ?></p>
    </div>

    <div class="editproductfield" style="">


    <form action="/editproductdetail" method="post" class="formeditshoes" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

    <!-- Input ini buat passing ID nya biar bisa diterima -->
    <input type="hidden" name="productid" value="<?php echo e($product->id); ?>">
  
    <label for="name" class="shoesinfolabel"><b>Shoes Name</b></label>
    <input type="text" name="shoesname" class="shoeseditfield">
    <br>

    <label for="psw" class="shoesinfolabel"><b>Price</b></label>
    <input type="number"  name="shoesprice" class="shoeseditfield">
    <br>

    <label for="description" class="shoesinfolabel"><b>Description</b></label>
    <input type="text" name="shoesdescription" class="shoeseditfield">
    <br>


    <input type="file" name="image" style="height:50px; margin-top: 1.5vh;">
    </label>

 

                <?php if($errors->any()): ?>
                    <div style="width:100%; display:flex;justify-content: center;align-items: center; " role="alert">
                        <h3 style="color: red"><?php echo e($errors->first()); ?></h3>
                    </div>
                <?php endif; ?> 
    

    <button type="submit" class="registerButton">Login</button>


</form>

        
    </div>
    <?php if($errors->any()): ?>
                    <div style="width:100%; display:flex;align-items: center; padding-left: 3vh " role="alert">
                        <h3 style="color: red"><?php echo e($errors->first()); ?></h3>
                    </div>
    <?php endif; ?>  
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/editproduct.blade.php ENDPATH**/ ?>