<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Just Du It - Shoes Store</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body style="margin: 0; padding: 0;">
    <div class="sidebar bar-block card animate-left" style="display:none" id="sidebar">
        <button class="bar-item button large" onclick="closeSidebar()">&times;</button>
            <a href="/" class="bar-item button large">View All Shoe</a>
        <?php if(Auth::User()): ?>
            <?php if(Auth::User()->role->name == 'Member'): ?>
            <a href="/cart" class="bar-item button large">View Cart</a>
            <a href="/viewtransaction" class="bar-item button large">My Transactions</a>
            <?php elseif(Auth::User()->role->name == 'Admin'): ?>
            <a href="/addproduct" class="bar-item button large">Add Shoe</a>
            <a href="/alltransaction" class="bar-item button large">View All Transactions</a>
            <?php endif; ?>
        <?php endif; ?>

    </div>

    <div id="main">
        <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="body_container">
            <div class="maincontent">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <script>
    function openSidebar() {
        document.getElementById("main").style.marginLeft = "30vh";
        document.getElementById("sidebar").style.width = "30vh";
        document.getElementById("sidebar").style.display = "block";
        document.getElementById("openNav").style.display = 'none';
    }
    function closeSidebar() {
        document.getElementById("main").style.marginLeft = "0%";
        document.getElementById("sidebar").style.display = "none";
        document.getElementById("openNav").style.display = "inline-block";
    }
    </script>


</body>
</html>
<?php /**PATH X:\ProgramData\NEW DLs\Technical Test to Fulltime 22-2\JustDuIt\resources\views/layout/master.blade.php ENDPATH**/ ?>