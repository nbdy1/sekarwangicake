
<?php $__env->startSection('content'); ?>

<div class="addshoesbox" style="margin-top: 10%">
        <div class="addshoesboxheader" style="width: 100%; height:50px; background:#50a4e4">
            <h2 style="color: black; font-weight: 100">Add Shoes</h2>
        </div>
        
    <form action="/addproduct" method="post" class="formaddshoes" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

  <div class="container">
  
    <label for="name"><b>Shoes Name</b></label>
    <input type="text" name="shoesname" class="shoesfield">

    <label for="psw"><b>Price</b></label>
    <input type="number"  name="shoesprice" class="shoesfield">

    <label for="description"><b>Description</b></label>
    <input type="text" name="shoesdescription" class="shoesfield">

    <label for="image" style="">
    <input type="file" name="image" style="height:50px; margin-top: 1.5vh;">
    </label>

 

                <?php if($errors->any()): ?>
                    <div style="width:100%; display:flex;justify-content: center;align-items: center; " role="alert">
                        <h3 style="color: red"><?php echo e($errors->first()); ?></h3>
                    </div>
                <?php endif; ?>
    

    <button type="submit" class="registerButton">Login</button>

  </div>


</form>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/addproduct.blade.php ENDPATH**/ ?>