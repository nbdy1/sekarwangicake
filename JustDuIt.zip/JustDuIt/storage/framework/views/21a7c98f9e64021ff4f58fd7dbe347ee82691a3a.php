<?php $__env->startSection('content'); ?>

<style>
    .header{
        color: black;
        font-weight: 100;
    }

    .viewtransactionheader {
        width: 100%;
        height:50px;
        background:#76e393;
        display:flex;
        justify-content: center;
        align-items: center;
    }

    @media  screen and (max-width: 768px) {
        .viewtransactionheader {
            width: 100vw;
            height: 10vh;
            background:#76e393;
            display:flex;
            justify-content: center;
            align-items: center;
        }

        .transactionbox{
            margin-top:10%;
            margin-bottom:10%;
        }

        .viewtransactionbox{
            height: auto;
            width:  100vw;
            margin: 0 auto;
            margin-top: 25%;
        }

        .transactioninformation{
            flex-direction: column;
        }

        .transactiontotal{
            width: 100%;
            justify-content: center;
        }
    }
</style>


<div class="viewtransactionbox">
    <div class="viewtransactionheader">
        <h2 class="header">View All Transaction</h2>
    </div>


   <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="transactionbox">
        <div class="transactioninformation">
           <div class="transactiondate">
                <h4 class="cartdetailtext"><?php echo e($header->transaction_date); ?></h4>
           </div>

           <?php $__currentLoopData = $header->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $total = 0;
            $total += $detail->product->price * $detail->quantity; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <div class="transactiontotal">
                <h4 class="cartdetailtext">Total Rp <?php echo e(number_format($total)); ?></h4>
           </div>



        </div>
        <div class="transactionimages" style="width: 70%; align-self: center">
        <?php $__currentLoopData = $header->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset('assets/' . $detail->product->image)); ?>" alt="" style="width: 30%">

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
   </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\ProgramData\NEW DLs\Technical Test to Fulltime 22-2\JustDuIt\resources\views/transaction.blade.php ENDPATH**/ ?>