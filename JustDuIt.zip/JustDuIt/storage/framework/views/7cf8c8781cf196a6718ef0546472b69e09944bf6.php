
<?php $__env->startSection('content'); ?>
<div class="shoesdetailcontainer" style="margin-top: 10%;">
    <div class="shoesdetailimage" style="float: left;">
    <img src="<?php echo e(asset('assets/' . $product->image)); ?>" style="height: 30vh; width: 20vw;" alt="">

    </div>

    <div class="shoesinfo" style="float: left; margin-left: 1vw;">
        <h3 style="font-size: 1.5em; max-width:15vw; font-weight: 100; display: block; margin-bottom: 0px; margin-top: 0px"><span style="font-weight: bold">Name: </span><?php echo e($product->name); ?></h3>
        <h3 style="font-weight: 100; padding-top: 1vh;margin-top: 1vh; margin-bottom: 0px; margin-top: 0px"><span style="font-weight: bold;">Price: </span> Rp<?php echo e(number_format($product->price)); ?></h3>
        <h3 style="font-weight: 100; padding-top: 1vh;margin-top: 1vh; margin-bottom: 0px; margin-top: 0px"><span style="font-weight: bold;">Description: </span> </h3>
        <p style="max-width: 30vw; margin-top: 0px; margin-bottom: 1vh"><?php echo e($product->description); ?></p>

    <?php if(Auth::check()): ?>
        <?php if(Auth::User()->role->name == 'Member'): ?>
        <a href="/addtocartpage/<?php echo e($product->id); ?>" style="text-decoration: none"><span style="color:#59bfff">Add to Cart</span></a>
        <?php elseif(Auth::User()->role->name == 'Admin'): ?>
        <a href="/editproductpage/<?php echo e($product->id); ?>" style="text-decoration: none"><span style="color:#59bfff ">Update Shoe</span></a>


    <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/productdetail.blade.php ENDPATH**/ ?>