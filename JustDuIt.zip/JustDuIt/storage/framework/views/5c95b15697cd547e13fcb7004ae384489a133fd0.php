
<?php $__env->startSection('content'); ?>


<div class="home_container">

<div class="shoescontent" style="margin-top: 10%; width:70vw">
    <div class="shoescontentheader" style="width: 100%; height:50px; background:#50a4e4; display:flex;justify-content: center; align-items: center; " >
            <h2 style="color: black; font-weight: 100;">View Shoes</h2>
    </div>

    <div style="width:100%;" class="cards_container">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="max-width:20vw; background: #ffffff; float:left; padding: 2vh;" class="cards">
            <div class="cards_image">
                <img src="<?php echo e(asset('assets/airforce1tw.jpg')); ?>" alt="" style="width: 70%; height:50%">
            </div>

            <div class="cards_detail">
                <a href="<?php echo e(url('productdetail', ['idproduct' => $product->id])); ?>" style="text-decoration: none;"><h4 style="color: #59bfff; font-weight: 150; padding: 10px;"><?php echo e($product->name); ?></h4></a>
                <p>Rp<?php echo e(number_format($product->price)); ?></p>

            </div>


        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

</div>

</div>

<!-- <?php echo e($products->links()); ?> -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/home.blade.php ENDPATH**/ ?>