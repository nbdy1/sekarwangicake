
<?php $__env->startSection('content'); ?>


<div class="viewcartbox">
   <div class="viewcartheader">
   <h2 style="color: black; font-weight: 100">View Cart</h2>
   </div>

   <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="cartrow">
        <div class="cartcolumn1">
        <img src="<?php echo e(asset('assets/' . $cart->product->image)); ?>" alt="" style="width: 15vw;">
        </div>

        <div class="cartcolumn2">
            <span style=" color: #50a4e4; font-size: 1em;"><?php echo e($cart->product->name); ?></span>
        </div>

        <div class="cartcolumn3">
            <span style=" font-size: 1em;"><?php echo e($cart->quantity); ?></span>
        </div>

        <div class="cartcolumn4">
        <span style=" font-size: 1em;">Rp <?php echo e(number_format($cart->quantity*$cart->product->price)); ?></span>
        </div>

        <div class="cartcolumn5">
            <a href="editcart/<?php echo e($cart->product->id); ?>">
            <button class="cartitembutton">
                Edit
            </button>
            </a>

        </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <div style="width: 100%; display: flex; justify-content: end;">
        <a href="/checkout">
        <button class="checkoutbutton">
            Checkout
        </button>
        </a>
   </div>
   
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/cart.blade.php ENDPATH**/ ?>