<?php $__env->startSection('content'); ?>

<style>
    .shoescontent {
        margin-top: 10%;
        width: 90vw;
    }

    .shoescontentheader {
        width: 100%;
        height: 50px;
        background:#50a4e4;
        display:flex;
        justify-content: center;
        align-items: center;
    }

    .headertext {
        color: black;
        font-weight: 100;
    }

    .cards_container{
        width:100%;
    }

    .cards{
        max-width:28vw;
        background: #ffffff;
        float:left;
        padding: 2vh;
    }

    .prodimg{
        width: 30vw;
        height: 30vh;
        object-fit: cover;
        float: left;
    }

    .detaillink{
        text-decoration: none;
    }

    .prodname{
        color: #59bfff;
        font-weight: 150;
        padding: 10px;
    }

    @media  screen and (max-width: 768px) {
        .home_container{
            margin-top: 25%;
        }

        .prodimg{
            width: 100vw;
            height: 50%;
        }

        .shoescontent {
            margin-top: 0%;
            width: 100vw;
        }

        .shoescontentheader {
            width: 100vw;
            height: 10vh;
            background:#50a4e4;
            display:flex;
            justify-content: center;
            align-items: center;
        }
    }
</style>

<div class="home_container">

<div class="shoescontent">
    <div class="shoescontentheader">
            <h2 class="headertext">View Shoes</h2>
    </div>

    <div class="cards_container">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cards">
            <div class="cards_image">
                <img src="<?php echo e(asset('assets/' . $product->image)); ?>" alt="" class="prodimg">
            </div>

            <div class="cards_detail">
                <a class ="detaillink" href="<?php echo e(url('productdetail', ['idproduct' => $product->id])); ?>"><h4 class="prodname"><?php echo e($product->name); ?></h4></a>
                <p>Rp<?php echo e(number_format($product->price)); ?></p>

            </div>


        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

</div>

</div>

<center>
    <div class="paginator">
    <?php echo e($products->links()); ?>

    </div>
</center>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt2\JustDuIt\resources\views/home.blade.php ENDPATH**/ ?>