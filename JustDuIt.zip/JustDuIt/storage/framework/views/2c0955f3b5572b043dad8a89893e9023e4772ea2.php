
<?php $__env->startSection('content'); ?>


<div class="viewtransactionbox">
   <div class="viewtransactionheader">
   <h2 style="color: black; font-weight: 100">View All Transaction</h2>
   </div>


   <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="transactionbox">
        <div class="transactioninformation">
           <div class="transactiondate">
                <h4 class="cartdetailtext"><?php echo e($header->transaction_date); ?></h4>
           </div>

           <?php $__currentLoopData = $header->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php $total = 0; ?>
           <?php $total += $detail->product->price * $detail->quantity; ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <div class="transactiontotal">
                <h4 class="cartdetailtext">Total Rp <?php echo e(number_format($total)); ?></h4>
           </div>

           
            
        </div>
        <div class="transactionimages" style="width: 70%; align-self: center">
        <?php $__currentLoopData = $header->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(asset('assets/' . $detail->product->image)); ?>" alt="" style="width: 30%">
                
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
   </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
   
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\JustDuIt\resources\views/transaction.blade.php ENDPATH**/ ?>