<footer class="bg-primary text-center text-secondary rounded-t-xl py-6 px-6">
    <p>&copy; {{ date('Y') }} Sekarwangi Cake. All rights reserved.</p>
</footer>
