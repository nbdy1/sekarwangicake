<button
    class="bg-secondary  border border-b-8 border-r-8 border-primary  shadow-lg hover:shadow-sm text-xl px-3 py-2 rounded-2xl text-primary font-baloo font-bold">Discover</button>
