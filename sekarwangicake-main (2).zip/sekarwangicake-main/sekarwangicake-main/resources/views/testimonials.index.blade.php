<div class="bg-gray-100 p-4">
    <div class="max-w-2xl mx-auto">
        <div class="flex space-x-4 overflow-x-auto p-4">
            @foreach ($testimonials as $testimonial)
                <div class="w-64 p-4 bg-white rounded shadow-lg">
                    <p class="text-gray-700 text-sm">{{ $testimonial->content }}</p>
                    <p class="text-gray-600 mt-2">- {{ $testimonial->name }}</p>
                </div>
            @endforeach
        </div>
    </div>
</div>
