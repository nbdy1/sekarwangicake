@extends('layouts.main')
@section('content')
    <div class="h-screen flex flex-col">
        <p class="text-6xl font-baloo font-bold  text-center text-primary my-6">Catalogue</p>
    </div>
@endsection
